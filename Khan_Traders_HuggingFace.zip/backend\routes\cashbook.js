const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all cashbook records
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM cashbook ORDER BY date DESC');

        // Calculate current balance
        const [balanceResult] = await db.query(`
      SELECT 
        SUM(CASE WHEN type = 'IN' THEN amount ELSE 0 END) - 
        SUM(CASE WHEN type = 'OUT' THEN amount ELSE 0 END) as current_balance
      FROM cashbook
    `);

        res.json({
            records: rows,
            current_balance: balanceResult[0].current_balance || 0
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add a manual cashbook entry
router.post('/', async (req, res) => {
    const { type, amount, description } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO cashbook (type, amount, description, reference_type) VALUES (?, ?, ?, ?)',
            [type, amount, description, 'Other']
        );
        res.status(201).json({ id: result.insertId, message: 'Cash entry added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
