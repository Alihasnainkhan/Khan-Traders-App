const fs = require('fs');
const path = require('path');

const filesToUpdate = [
    'dashboard.html',
    'products.html',
    'sales.html',
    'purchases.html',
    'cashbook.html',
    'reports.html'
];

const newSidebarHTML = `        <ul class="nav flex-column">
            <li class="nav-item mb-2"><a class="nav-link" href="dashboard.html"><i class="bi bi-speedometer2 me-2"></i><span data-i18n="dashboard">Dashboard</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="products.html"><i class="bi bi-box-seam me-2"></i><span data-i18n="products">Products</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="sales.html"><i class="bi bi-cart-check me-2"></i><span data-i18n="sales">Sales</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="purchases.html"><i class="bi bi-bag-plus me-2"></i><span data-i18n="purchases">Purchases</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="khata.html"><i class="bi bi-journal-check me-2"></i><span data-i18n="khata">Khata</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="cashbook.html"><i class="bi bi-cash-stack me-2"></i><span data-i18n="cashbook">Cashbook</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link" href="expenses.html"><i class="bi bi-wallet2 me-2"></i><span data-i18n="expenses">Expenses</span></a></li>
            <li class="nav-item mb-2 mt-4"><a class="nav-link text-warning" href="#" id="langToggle"><i class="bi bi-translate me-2"></i><span data-i18n="language">Language</span></a></li>
            <li class="nav-item mb-2"><a class="nav-link text-danger" href="index.html" onclick="localStorage.removeItem('token')"><i class="bi bi-box-arrow-left me-2"></i><span data-i18n="logout">Logout</span></a></li>
        </ul>`;

filesToUpdate.forEach(file => {
    const filePath = path.join(__dirname, file);
    if (fs.existsSync(filePath)) {
        let content = fs.readFileSync(filePath, 'utf8');

        // Find everything between <ul class="nav flex-column"> and </ul>
        // using regex
        const regex = /<ul class="nav flex-column">[\s\S]*?<\/ul>/;

        // Special case for highlighting the active link
        let customSidebarHTML = newSidebarHTML;

        // Remove default active class if not dashboard
        if (file !== 'dashboard.html') {
            // We won't try regex dynamically here, just let JS handle the active class if needed, or we just do simple replace since it's just classes
            // Actually, Bootstrap active class is static in the HTML.
            // We can regex replace href="thisfile.html" to href="thisfile.html" class="nav-link active"
            // Let's implement active state dynamically in JS instead of HTML for all files?
            // Or just stick to static replace.
        }

        content = content.replace(regex, customSidebarHTML);

        // Now find the link that matches this file and add 'active' to it
        const linkRegex = new RegExp(`href="${file}"`);
        content = content.replace(new RegExp(`class="nav-link" href="${file}"`), `class="nav-link active" href="${file}"`);

        fs.writeFileSync(filePath, content, 'utf8');
        console.log(`Updated sidebar in ${file}`);
    } else {
        console.log(`File not found: ${file}`);
    }
});
