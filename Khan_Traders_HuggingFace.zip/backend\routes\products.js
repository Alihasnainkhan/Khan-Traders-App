const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all products
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM products ORDER BY name ASC');
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add a product
router.post('/', async (req, res) => {
    const { name, category, quantity, rate_per_unit } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO products (name, category, quantity, rate_per_unit) VALUES (?, ?, ?, ?)',
            [name, category, quantity || 0, rate_per_unit]
        );
        res.status(201).json({ id: result.insertId, message: 'Product added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Update a product
router.put('/:id', async (req, res) => {
    const { quantity, rate_per_unit } = req.body;
    try {
        await db.query(
            'UPDATE products SET quantity = ?, rate_per_unit = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
            [quantity, rate_per_unit, req.params.id]
        );
        res.json({ message: 'Product updated successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Delete a product
router.delete('/:id', async (req, res) => {
    try {
        await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        res.json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
