const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all sales
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query(`
      SELECT s.*, p.name as product_name, p.category 
      FROM sales s 
      JOIN products p ON s.product_id = p.id 
      ORDER BY s.date DESC
    `);
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create a sale entry
router.post('/', async (req, res) => {
    const { product_id, quantity, rate, total_amount, customer_name, payment_type, party_id } = req.body;

    try {
        // Start transaction
        await db.query('START TRANSACTION');

        // Insert sale
        const [result] = await db.query(
            'INSERT INTO sales (product_id, quantity, rate, total_amount, customer_name, payment_type) VALUES (?, ?, ?, ?, ?, ?)',
            [product_id, quantity, rate, total_amount, customer_name, payment_type]
        );

        // Update product stock
        await db.query(
            'UPDATE products SET quantity = quantity - ? WHERE id = ?',
            [quantity, product_id]
        );

        // If Cash, add to cashbook
        if (payment_type === 'Cash') {
            await db.query(
                'INSERT INTO cashbook (type, amount, description, reference_type, reference_id) VALUES (?, ?, ?, ?, ?)',
                ['IN', total_amount, `Sale to ${customer_name}`, 'Sale', result.insertId]
            );
        } else if (payment_type === 'Credit') {
            if (!party_id) throw new Error('Party ID required for Credit Sale');

            // Add to Party Khata (Customer owes us more -> balance increases)
            await db.query('UPDATE parties SET balance = balance + ? WHERE id = ?', [total_amount, party_id]);

            // Log transaction
            await db.query(
                'INSERT INTO party_transactions (party_id, amount, transaction_type, reference_id) VALUES (?, ?, ?, ?)',
                [party_id, total_amount, 'Credit Sale', result.insertId]
            );
        }

        await db.query('COMMIT');
        res.status(201).json({ id: result.insertId, message: 'Sale recorded successfully' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: error.message || 'Server error during sale processing' });
    }
});

module.exports = router;
