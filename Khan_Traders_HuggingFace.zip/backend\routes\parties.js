const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all parties (Customers and Suppliers)
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM parties ORDER BY name ASC');
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Get single party ledger (transactions)
router.get('/:id/ledger', async (req, res) => {
    try {
        const [partyDetails] = await db.query('SELECT * FROM parties WHERE id = ?', [req.params.id]);
        const [transactions] = await db.query('SELECT * FROM party_transactions WHERE party_id = ? ORDER BY date DESC', [req.params.id]);

        if (partyDetails.length === 0) return res.status(404).json({ message: 'Party not found' });

        res.json({
            party: partyDetails[0],
            transactions: transactions
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add a new party
router.post('/', async (req, res) => {
    const { name, party_type, phone } = req.body;
    try {
        const [result] = await db.query(
            'INSERT INTO parties (name, party_type, phone) VALUES (?, ?, ?)',
            [name, party_type, phone || null]
        );
        res.status(201).json({ id: result.insertId, message: 'Party added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Record a Payment (Receive from Customer OR Give to Supplier)
router.post('/:id/payment', async (req, res) => {
    const party_id = req.params.id;
    const { amount, transaction_type, description } = req.body;
    // transaction_type: 'Payment Received' (Money IN), 'Payment Given' (Money OUT)

    try {
        await db.query('START TRANSACTION');

        // 1. Get party details
        const [partyRows] = await db.query('SELECT party_type FROM parties WHERE id = ?', [party_id]);
        if (partyRows.length === 0) throw new Error('Party not found');

        // 2. Update balance
        // If Customer pays us: balance decreases. If we pay Supplier: balance decreases (gets less negative or moves to 0)
        // Mathematically: Payment Received decreases balance. Payment Given increases balance (less negative).
        const balanceModifier = (transaction_type === 'Payment Received') ? `balance - ?` : `balance + ?`;

        await db.query(`UPDATE parties SET balance = ${balanceModifier} WHERE id = ?`, [amount, party_id]);

        // 3. Insert transaction log
        const [transResult] = await db.query(
            'INSERT INTO party_transactions (party_id, amount, transaction_type) VALUES (?, ?, ?)',
            [party_id, amount, transaction_type]
        );

        // 4. Update Cashbook
        const cashbookType = (transaction_type === 'Payment Received') ? 'IN' : 'OUT';
        const transnDesc = (transaction_type === 'Payment Received') ? `Received payment from party` : `Gave payment to party`;
        const finalDesc = description ? `${transnDesc}: ${description}` : transnDesc;

        await db.query(
            'INSERT INTO cashbook (type, amount, description, reference_type, reference_id) VALUES (?, ?, ?, ?, ?)',
            [cashbookType, amount, finalDesc, 'Payment', transResult.insertId]
        );

        await db.query('COMMIT');
        res.status(200).json({ message: 'Payment recorded successfully' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: error.message || 'Server error' });
    }
});

module.exports = router;
