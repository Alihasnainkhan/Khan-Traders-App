const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all purchases
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query(`
      SELECT p_log.*, p.name as product_name, p.category 
      FROM purchases p_log 
      JOIN products p ON p_log.product_id = p.id 
      ORDER BY p_log.date DESC
    `);
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Create a purchase entry
router.post('/', async (req, res) => {
    const { product_id, quantity, rate, total_amount, supplier_name, payment_type, party_id } = req.body;

    try {
        // Start transaction
        await db.query('START TRANSACTION');

        // Insert purchase
        const [result] = await db.query(
            'INSERT INTO purchases (product_id, quantity, rate, total_amount, supplier_name) VALUES (?, ?, ?, ?, ?)',
            [product_id, quantity, rate, total_amount, supplier_name]
        );

        // Update product stock
        await db.query(
            'UPDATE products SET quantity = quantity + ? WHERE id = ?',
            [quantity, product_id]
        );

        // If Cash, add to cashbook
        if (payment_type === 'Cash') {
            await db.query(
                'INSERT INTO cashbook (type, amount, description, reference_type, reference_id) VALUES (?, ?, ?, ?, ?)',
                ['OUT', total_amount, `Purchase from ${supplier_name}`, 'Purchase', result.insertId]
            );
        } else if (payment_type === 'Credit') {
            if (!party_id) throw new Error('Party ID required for Credit Purchase');

            // Add to Party Khata (We owe Supplier more -> balance decreases / becomes more negative)
            await db.query('UPDATE parties SET balance = balance - ? WHERE id = ?', [total_amount, party_id]);

            // Log transaction
            await db.query(
                'INSERT INTO party_transactions (party_id, amount, transaction_type, reference_id) VALUES (?, ?, ?, ?)',
                [party_id, total_amount, 'Credit Purchase', result.insertId]
            );
        }

        await db.query('COMMIT');
        res.status(201).json({ id: result.insertId, message: 'Purchase recorded successfully' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: error.message || 'Server error during purchase processing' });
    }
});

module.exports = router;
