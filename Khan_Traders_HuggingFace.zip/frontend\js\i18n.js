// Apply Bootstrap Dark Theme globally
document.documentElement.setAttribute('data-bs-theme', 'dark');

const translations = {
    en: {
        dashboard: "Dashboard",
        products: "Products",
        sales: "Sales",
        purchases: "Purchases",
        cashbook: "Cashbook",
        expenses: "Expenses",
        khata: "Khata (Ledger)",
        reports: "Reports",
        logout: "Logout",
        total_stock: "Total Stock",
        daily_sales: "Today's Sales",
        daily_purchases: "Today's Purchases",
        cash_in_hand: "Cash in Hand",
        profit_loss: "Profit/Loss (Today)",
        add_product: "Add New Product",
        add_sale: "New Sale Entry",
        add_purchase: "New Purchase Entry",
        add_expense: "Add Expense",
        add_party: "Add Customer/Supplier",
        language: "Language",
        khan_traders: "Khan Traders"
    },
    ur: {
        dashboard: "ڈیش بورڈ",
        products: "مصنوعات",
        sales: "فروخت",
        purchases: "خریداری",
        cashbook: "کیش بک",
        expenses: "اخراجات",
        khata: "کھاتہ (لیجر)",
        reports: "رپورٹس",
        logout: "لاگ آؤٹ",
        total_stock: "کل اسٹاک",
        daily_sales: "آج کی فروخت",
        daily_purchases: "آج کی خریداری",
        cash_in_hand: "کیش ان ہینڈ",
        profit_loss: "نفع / نقصان (آج)",
        add_product: "نیا پروڈکٹ شامل کریں",
        add_sale: "نئی فروخت کا اندراج",
        add_purchase: "نئی خریداری کا اندراج",
        add_expense: "خرچ شامل کریں",
        add_party: "گاہک/سپلائر شامل کریں",
        language: "زبان",
        khan_traders: "خان ٹریڈرز"
    }
};

let currentLang = localStorage.getItem('lang') || 'en';

function toggleLanguage() {
    currentLang = currentLang === 'en' ? 'ur' : 'en';
    localStorage.setItem('lang', currentLang);
    applyTranslations();
    updateBodyDirection();
}

function updateBodyDirection() {
    if (currentLang === 'ur') {
        document.body.setAttribute('dir', 'rtl');
        document.body.classList.add('rtl-layout');
    } else {
        document.body.setAttribute('dir', 'ltr');
        document.body.classList.remove('rtl-layout');
    }
}

function applyTranslations() {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang] && translations[currentLang][key]) {
            el.textContent = translations[currentLang][key];
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    updateBodyDirection();
    applyTranslations();

    const langToggle = document.getElementById('langToggle');
    if (langToggle) {
        langToggle.addEventListener('click', (e) => {
            e.preventDefault();
            toggleLanguage();
        });
    }
});
