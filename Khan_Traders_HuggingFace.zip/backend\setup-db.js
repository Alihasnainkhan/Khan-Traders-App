const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function initDB() {
    try {
        console.log('Connecting to MySQL...');
        // Create connection without database selected
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            port: process.env.DB_PORT || 3306,
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASS || '',
            ssl: {
                rejectUnauthorized: true
            }
        });

        const dbName = process.env.DB_NAME || 'khan_traders';
        console.log(`Creating database ${dbName} if it does not exist...`);
        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\``);

        console.log(`Using database ${dbName}...`);
        await connection.query(`USE \`${dbName}\``);

        console.log('Reading schema.sql...');
        const schemaPath = path.join(__dirname, '../database/schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');

        // Split the file into individual queries
        const queries = schema.split(';').filter(q => q.trim().length > 0);

        console.log(`Executing ${queries.length} queries...`);
        for (const query of queries) {
            await connection.query(query);
        }

        console.log('Database initialization completed successfully!');
        await connection.end();
        process.exit(0);
    } catch (error) {
        console.error('Error during database initialization:', error);
        process.exit(1);
    }
}

initDB();
