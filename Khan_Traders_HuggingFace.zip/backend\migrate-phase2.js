const mysql = require('mysql2/promise');
require('dotenv').config({ path: '../.env' }); // Adjusted for this script's location

async function migrate() {
    try {
        console.log('Connecting to MySQL...');
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASS || '',
            database: process.env.DB_NAME || 'khan_traders'
        });

        console.log('Updating cashbook enum...');
        await connection.query(`ALTER TABLE cashbook MODIFY COLUMN reference_type ENUM('Sale', 'Purchase', 'Other', 'Expense', 'Payment') DEFAULT 'Other'`);

        console.log('Creating expenses table...');
        await connection.query(`
            CREATE TABLE IF NOT EXISTS expenses (
                id INT AUTO_INCREMENT PRIMARY KEY,
                amount DECIMAL(15,2) NOT NULL,
                description TEXT NOT NULL,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        console.log('Creating parties (Khata) table...');
        await connection.query(`
            CREATE TABLE IF NOT EXISTS parties (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                party_type ENUM('Customer', 'Supplier') NOT NULL,
                phone VARCHAR(20) DEFAULT NULL,
                balance DECIMAL(15,2) DEFAULT 0.00
            )
        `);

        console.log('Creating party_transactions table...');
        await connection.query(`
            CREATE TABLE IF NOT EXISTS party_transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                party_id INT NOT NULL,
                amount DECIMAL(15,2) NOT NULL,
                transaction_type ENUM('Payment Received', 'Payment Given', 'Credit Sale', 'Credit Purchase') NOT NULL,
                reference_id INT DEFAULT NULL,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE CASCADE
            )
        `);

        console.log('Phase 2 Migration completed successfully!');
        await connection.end();
        process.exit(0);
    } catch (error) {
        console.error('Migration failed:', error);
        process.exit(1);
    }
}

migrate();
