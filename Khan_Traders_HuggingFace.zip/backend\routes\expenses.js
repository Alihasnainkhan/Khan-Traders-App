const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all expenses
router.get('/', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM expenses ORDER BY date DESC');
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Add a new expense
router.post('/', async (req, res) => {
    const { amount, description } = req.body;

    try {
        await db.query('START TRANSACTION');

        // 1. Insert into expenses
        const [result] = await db.query(
            'INSERT INTO expenses (amount, description) VALUES (?, ?)',
            [amount, description]
        );

        // 2. Insert into cashbook as OUT
        await db.query(
            'INSERT INTO cashbook (type, amount, description, reference_type, reference_id) VALUES (?, ?, ?, ?, ?)',
            ['OUT', amount, `Shop Expense: ${description}`, 'Expense', result.insertId]
        );

        await db.query('COMMIT');
        res.status(201).json({ id: result.insertId, message: 'Expense added successfully' });
    } catch (error) {
        await db.query('ROLLBACK');
        console.error(error);
        res.status(500).json({ message: 'Server error during expense processing' });
    }
});

module.exports = router;
