// Use relative path for production (Hugging Face) or fallback to localhost for development
const API_URL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'http://localhost:5000/api'
    : '/api';

async function fetchAPI(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(`${API_URL}${endpoint}`, {
            ...options,
            headers
        });

        // We expect mostly JSON responses
        const data = await response.json().catch(() => null);

        if (!response.ok) {
            throw new Error(data?.message || 'API request failed');
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        alert('Error: ' + error.message);
        throw error;
    }
}

const api = {
    // Auth
    login: async (username, password) => {
        // Basic mock login for now - assuming admin/admin123
        if (username === 'admin' && password === 'admin123') {
            localStorage.setItem('token', 'mock_token');
            localStorage.setItem('user', JSON.stringify({ username }));
            return true;
        }
        throw new Error('Invalid credentials');
    },

    // Dashboard
    getDashboardSummary: () => fetchAPI('/dashboard/summary'),

    // Products
    getProducts: () => fetchAPI('/products'),
    addProduct: (data) => fetchAPI('/products', { method: 'POST', body: JSON.stringify(data) }),
    updateProduct: (id, data) => fetchAPI(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    deleteProduct: (id) => fetchAPI(`/products/${id}`, { method: 'DELETE' }),

    // Sales
    getSales: () => fetchAPI('/sales'),
    addSale: (data) => fetchAPI('/sales', { method: 'POST', body: JSON.stringify(data) }),

    // Purchases
    getPurchases: () => fetchAPI('/purchases'),
    addPurchase: (data) => fetchAPI('/purchases', { method: 'POST', body: JSON.stringify(data) }),

    // Cashbook
    getCashbook: () => fetchAPI('/cashbook'),
    addCashbookEntry: (data) => fetchAPI('/cashbook', { method: 'POST', body: JSON.stringify(data) }),

    // Expenses
    getExpenses: () => fetchAPI('/expenses'),
    addExpense: (data) => fetchAPI('/expenses', { method: 'POST', body: JSON.stringify(data) }),

    // Parties & Khata
    getParties: () => fetchAPI('/parties'),
    addParty: (data) => fetchAPI('/parties', { method: 'POST', body: JSON.stringify(data) }),
    getPartyLedger: (id) => fetchAPI(`/parties/${id}/ledger`),
    recordPartyPayment: (id, data) => fetchAPI(`/parties/${id}/payment`, { method: 'POST', body: JSON.stringify(data) })
};
