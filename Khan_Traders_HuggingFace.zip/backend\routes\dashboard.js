const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get dashboard summary
router.get('/summary', async (req, res) => {
    try {
        const today = new Date().toISOString().split('T')[0];

        // Total Stock
        const [stockRes] = await db.query('SELECT SUM(quantity) as total_stock FROM products');

        // Today's Sales
        const [salesRes] = await db.query('SELECT SUM(total_amount) as daily_sales FROM sales WHERE DATE(date) = ?', [today]);

        // Today's Purchases
        const [purchasesRes] = await db.query('SELECT SUM(total_amount) as daily_purchases FROM purchases WHERE DATE(date) = ?', [today]);

        // Today's Expenses
        const [expenseRes] = await db.query('SELECT SUM(amount) as daily_expenses FROM expenses WHERE DATE(date) = ?', [today]);

        // Cash in Hand
        const [cashRes] = await db.query(`
      SELECT 
        SUM(CASE WHEN type = 'IN' THEN amount ELSE 0 END) - 
        SUM(CASE WHEN type = 'OUT' THEN amount ELSE 0 END) as cash_in_hand
      FROM cashbook
    `);

        // Simple profit estimation for today (Sales - Purchases - Expenses)
        const dailySales = salesRes[0].daily_sales || 0;
        const dailyPurchases = purchasesRes[0].daily_purchases || 0;
        const dailyExpenses = expenseRes[0].daily_expenses || 0;
        const profitLoss = dailySales - dailyPurchases - dailyExpenses;

        res.json({
            total_stock: stockRes[0].total_stock || 0,
            daily_sales: dailySales,
            daily_purchases: dailyPurchases,
            cash_in_hand: cashRes[0].cash_in_hand || 0,
            daily_profit_loss: profitLoss
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
